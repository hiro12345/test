﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestLibrary1
{
    public class TestClass1
    {
        public static  string CreateMessage(string msg)
        {
            return "入力値："+msg;
        }
    }
}
